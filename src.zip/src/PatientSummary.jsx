import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getPatientById, getRecordsByPatient, getActiveDoctorSession } from './dataService';

export default function PatientSummary() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [patient, setPatient] = useState(null);
  const [records, setRecords] = useState([]);
  const [doctor, setDoctor] = useState(null);

  useEffect(() => {
    setPatient(getPatientById(id));
    setRecords(getRecordsByPatient(id));
    setDoctor(getActiveDoctorSession());
  }, [id]);

  if (!patient) return <div style={{ padding: '2rem', textAlign: 'center' }}>Loading Patient Data...</div>;

  const totalScans = records.length;
  // Calculate abnormal based on dynamic criteria
  const abnormalScans = records.filter(r => r.status === 'ABNORMAL' || r.analysis?.status === 'ABNORMAL').length;
  const normalScans = totalScans - abnormalScans;
  
  let totalFNSZ = 0, totalGNSZ = 0, totalCPSZ = 0;
  
  records.forEach(r => {
    if (r.analysis && r.analysis.summary) {
      totalFNSZ += r.analysis.summary.FNSZ || 0;
      totalGNSZ += r.analysis.summary.GNSZ || 0;
      totalCPSZ += r.analysis.summary.CPSZ || 0;
    }
  });

  const totalSeizureWindows = totalFNSZ + totalGNSZ + totalCPSZ;

  const handlePrint = () => {
    const printContent = document.getElementById('printable-report').innerHTML;
    const printWindow = window.open('', '_blank', 'width=1100,height=900');
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>EpiDetect_Report_${patient.id}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
            body { 
              font-family: 'Inter', Arial, sans-serif; 
              margin: 0; 
              padding: 40px; 
              color: #0f172a; 
              -webkit-print-color-adjust: exact !important; 
              print-color-adjust: exact !important; 
            }
            @page { size: A4; margin: 10mm; }
            * { box-sizing: border-box; }
            .prevent-break { page-break-inside: avoid; break-inside: avoid; }
            table { page-break-inside: auto; }
            tr { page-break-inside: avoid; page-break-after: auto; }
          </style>
        </head>
        <body>
          ${printContent}
          <script>
            setTimeout(function() {
              window.print();
              window.close();
            }, 300);
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', background: '#f8fafc', padding: '2rem', minHeight: '100vh', fontFamily: "'Inter', Arial, sans-serif" }}>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', background: '#ffffff', padding: '1rem 2rem', borderRadius: '12px', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' }}>
        <button onClick={() => navigate(-1)} style={{ background: '#e2e8f0', color: '#0f172a', border: 'none', padding: '10px 20px', borderRadius: '8px', fontWeight: '600', cursor: 'pointer' }}>
          &larr; Back
        </button>
        <button onClick={handlePrint} style={{ background: '#2563eb', color: '#ffffff', border: 'none', padding: '10px 24px', borderRadius: '8px', fontWeight: '600', cursor: 'pointer', display: 'flex', gap: '8px', alignItems: 'center', boxShadow: '0 4px 14px 0 rgba(37, 99, 235, 0.39)' }}>
          Export Official PDF
        </button>
      </div>

      <div id="printable-report" style={{ background: '#ffffff', padding: '40px', borderRadius: '0', color: '#0f172a' }}>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '4px solid #0f172a', paddingBottom: '20px', marginBottom: '30px' }}>
          <div>
            <h1 style={{ margin: 0, fontSize: '2.5rem', fontWeight: '800', letterSpacing: '-1px' }}>
              <span style={{ color: '#0f172a' }}>Epi</span><span style={{ color: '#2563eb' }}>Detect</span>
            </h1>
            <div style={{ fontSize: '0.85rem', fontWeight: '600', letterSpacing: '2px', color: '#64748b', marginTop: '4px' }}>AI NEUROLOGICAL ANALYSIS</div>
          </div>
          <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', gap: '4px' }}>
            <div style={{ fontSize: '1.2rem', fontWeight: '800', color: '#dc2626' }}>CONFIDENTIAL</div>
            <div style={{ fontSize: '0.9rem', color: '#475569' }}><strong>Date:</strong> {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
            <div style={{ fontSize: '0.9rem', color: '#475569' }}><strong>Attending:</strong> Dr. {doctor?.name}</div>
          </div>
        </div>

        <div className="prevent-break" style={{ background: '#0f172a', color: '#ffffff', borderRadius: '12px', padding: '24px', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: '20px', marginBottom: '40px', boxShadow: '0 10px 15px -3px rgba(15, 23, 42, 0.3)' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '4px' }}>Patient Name</div>
            <div style={{ fontSize: '1.5rem', fontWeight: '700' }}>{patient.name}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '4px' }}>Patient ID</div>
            <div style={{ fontSize: '1.25rem', fontWeight: '600' }}>{patient.id}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '4px' }}>Age</div>
            <div style={{ fontSize: '1.25rem', fontWeight: '600' }}>{patient.age} yrs</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '4px' }}>Contact</div>
            <div style={{ fontSize: '1.25rem', fontWeight: '600' }}>{patient.phone || 'N/A'}</div>
          </div>
        </div>

        <div className="prevent-break" style={{ marginBottom: '40px' }}>
          <h3 style={{ fontSize: '1.2rem', color: '#0f172a', borderBottom: '2px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px' }}>Diagnostic Overview</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '15px' }}>
            <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: '800', color: '#3b82f6', lineHeight: '1' }}>{totalScans}</div>
              <div style={{ fontSize: '0.8rem', fontWeight: '700', color: '#64748b', marginTop: '8px', letterSpacing: '0.5px' }}>TOTAL SCANS</div>
            </div>
            <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: '800', color: '#10b981', lineHeight: '1' }}>{normalScans}</div>
              <div style={{ fontSize: '0.8rem', fontWeight: '700', color: '#065f46', marginTop: '8px', letterSpacing: '0.5px' }}>NORMAL</div>
            </div>
            <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: '800', color: '#ef4444', lineHeight: '1' }}>{abnormalScans}</div>
              <div style={{ fontSize: '0.8rem', fontWeight: '700', color: '#991b1b', marginTop: '8px', letterSpacing: '0.5px' }}>ABNORMAL SCANS</div>
            </div>
            <div style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: '800', color: '#d97706', lineHeight: '1' }}>{totalSeizureWindows}</div>
              <div style={{ fontSize: '0.8rem', fontWeight: '700', color: '#92400e', marginTop: '8px', letterSpacing: '0.5px' }}>SEIZURE BURDEN</div>
            </div>
          </div>
        </div>

        <div className="prevent-break">
          <h3 style={{ fontSize: '1.2rem', color: '#0f172a', borderBottom: '2px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px' }}>Comprehensive Scan History</h3>
          <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: '0', textAlign: 'left', fontSize: '0.95rem' }}>
            <thead>
              <tr>
                <th style={{ padding: '12px 16px', color: '#475569', fontWeight: '600', borderBottom: '2px solid #cbd5e1', width: '15%' }}>ID</th>
                <th style={{ padding: '12px 16px', color: '#475569', fontWeight: '600', borderBottom: '2px solid #cbd5e1', width: '20%' }}>Date</th>
                <th style={{ padding: '12px 16px', color: '#475569', fontWeight: '600', borderBottom: '2px solid #cbd5e1', width: '45%' }}>Source File</th>
                <th style={{ padding: '12px 16px', color: '#475569', fontWeight: '600', borderBottom: '2px solid #cbd5e1', width: '20%' }}>Diagnosis</th>
              </tr>
            </thead>
            <tbody>
              {records.length === 0 ? (
                <tr><td colSpan="4" style={{ padding: '30px', textAlign: 'center', color: '#94a3b8' }}>No EEG records logged.</td></tr>
              ) : (
                records.map((r, index) => {
                  
                  // Same logic here for the printed report
                  const isAbnormal = r.status === 'ABNORMAL' || r.analysis?.status === 'ABNORMAL';
                  const seizureWindows = r.analysis?.seizureWindows || 0;
                  
                  let badgeText = '✅ NORMAL';
                  let badgeBg = '#d1fae5';
                  let badgeColor = '#047857';

                  if (isAbnormal) {
                    if (seizureWindows > 0) {
                      badgeText = '🚨 ICTAL';
                      badgeBg = '#fee2e2';
                      badgeColor = '#b91c1c';
                    } else {
                      badgeText = '⚠️ INTERICTAL';
                      badgeBg = '#fefce8';
                      badgeColor = '#a16207';
                    }
                  }

                  return (
                    <tr key={r.id} style={{ background: index % 2 === 0 ? '#ffffff' : '#f8fafc' }}>
                      <td style={{ padding: '16px', fontWeight: '700', color: '#0f172a', borderBottom: '1px solid #e2e8f0' }}>{r.id}</td>
                      <td style={{ padding: '16px', color: '#475569', borderBottom: '1px solid #e2e8f0' }}>{r.date}</td>
                      <td style={{ padding: '16px', color: '#64748b', fontFamily: 'monospace', borderBottom: '1px solid #e2e8f0' }}>{r.fileName}</td>
                      <td style={{ padding: '16px', borderBottom: '1px solid #e2e8f0' }}>
                        <span style={{ 
                          padding: '6px 12px', 
                          borderRadius: '20px', 
                          fontSize: '0.8rem', 
                          fontWeight: '700', 
                          letterSpacing: '0.5px',
                          background: badgeBg, 
                          color: badgeColor 
                        }}>
                          {badgeText}
                        </span>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="prevent-break" style={{ marginTop: '60px', paddingTop: '30px', borderTop: '2px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div style={{ color: '#64748b', fontSize: '0.85rem', lineHeight: '1.5' }}>
            <strong style={{ color: '#0f172a' }}>EpiDetect Automated Analytics</strong><br />
            This report is AI-generated based on EDF signal processing.<br/>
            Final diagnosis requires physician verification.
          </div>
          <div style={{ width: '280px', textAlign: 'center' }}>
            <div style={{ borderBottom: '2px dashed #94a3b8', height: '40px', marginBottom: '10px' }}></div>
            <div style={{ fontSize: '1rem', color: '#0f172a', fontWeight: '700' }}>Dr. {doctor?.name}</div>
            <div style={{ fontSize: '0.8rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '1px', marginTop: '4px' }}>Attending Physician</div>
          </div>
        </div>

      </div>
    </div>
  );
}